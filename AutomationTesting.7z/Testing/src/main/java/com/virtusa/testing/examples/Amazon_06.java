package com.virtusa.testing.examples;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Amazon_06 {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		String baseurl="https://Amazon.in";
		driver.get(baseurl);
		WebElement sear = driver.findElement(By.id("twotabsearchtextbox"));
		sear.sendKeys("Da Vinci Books");
		System.out.println("product name entered");
		WebElement p=driver.findElement(By.xpath("//input[@value='Go']"));
		p.submit();
		System.out.println("Search action");

		List<WebElement> listElement = driver.findElements(By.className("a-size-medium"));
		List<WebElement> listElement2 = driver.findElements(By.className("a-price-whole"));
		for(int i =0;i<listElement.size();i++) 
		{
			String elementText = listElement.get(i).getText(); 
			String elementText2 = listElement2.get(i).getText(); 
			System.out.println(elementText+"\n "+ elementText2); 
		}

		 driver.quit();



	}








}
