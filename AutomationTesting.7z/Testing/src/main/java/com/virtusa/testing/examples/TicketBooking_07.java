package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TicketBooking_07 {

	public static void main(String[] args) {
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl=" http://newtours.demoaut.com/ "; //string url
		WebDriver driver=new ChromeDriver();
		//creating a driver of type web
		driver.get(baseurl); //opening base url in browser
		driver.findElement(By.name("userName")).sendKeys("mercury");
		System.out.println("user name entered ");
		driver.findElement(By.name("password")).sendKeys("mercury");
		System.out.println("password entered ");
		WebElement signin = driver.findElement(By.name("login"));
		signin.submit();
		System.out.println("login successfully  ");
		WebElement dropDown = driver.findElement(By.name("passCount"));  
		Select passenger = new Select(dropDown); 
		passenger.selectByIndex(3);
		System.out.println("selected 4 ");
		WebElement dropDown2 = driver.findElement(By.name("fromPort"));  
		Select dept = new Select(dropDown2); 
		dept.selectByValue("London");  
		System.out.println("selected dept  ");
		WebElement dropDown3 = driver.findElement(By.name("fromMonth"));  
		Select month = new Select(dropDown3); 
		month.selectByIndex(10);  
		System.out.println("selected month  ");
		WebElement dropDown4 = driver.findElement(By.name("fromDay"));  
		Select day = new Select(dropDown4); 
		day.selectByIndex(3);  
		System.out.println("selected date  ");
		WebElement dropDown5 = driver.findElement(By.name("toPort"));  
		Select arr = new Select(dropDown5); 
		arr.selectByValue("London");  
		System.out.println("selected arrival  ");
		WebElement dropDown6 = driver.findElement(By.name("toMonth"));  
		Select month1 = new Select(dropDown6); 
		month1.selectByIndex(10);  
		System.out.println("selected arrival month  ");
		WebElement dropDown7 = driver.findElement(By.name("toDay"));  
		Select day1 = new Select(dropDown7); 
		day1.selectByIndex(11);  
		System.out.println("selected arrival date  ");
		WebElement cont = driver.findElement(By.name("findFlights"));
		cont.submit();
        driver.quit();


	}

}
