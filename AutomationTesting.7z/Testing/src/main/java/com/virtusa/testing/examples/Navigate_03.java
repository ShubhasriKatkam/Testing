package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Navigate_03 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		String baseurl="https://Rediff.com";
		driver.get(baseurl);
		String t=driver.getTitle();
		System.out.println("Title"+t);
		driver.findElement(By.linkText("Sign in")).click();
		String l =driver.getTitle();
		System.out.println(driver.getTitle());
		driver.navigate().back();
		System.out.println("Redirected to home page");
		if(driver.getTitle().contains(t))
		{
			System.out.println("Page title contains"+t);
		}
		else
		{    
			System.out.println("Page title doesn't contains "+t);

		}
		driver.navigate().forward();
		System.out.println("forwarded");

		if(driver.getTitle().contains(l))
		{
			System.out.println("Page title contains "+l);
		}
		else
		{    
			System.out.println("Page title doesn't contains"+l);

		}
		driver.close();
		System.out.println("all the browser entities");
	    driver.quit();
	}
}

