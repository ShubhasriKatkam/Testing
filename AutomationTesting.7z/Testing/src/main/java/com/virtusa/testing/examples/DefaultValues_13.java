package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DefaultValues_13 {
	public static void main(String[] args) {

		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl=" http://www.fedex.com/sg/  "; //string url
		WebDriver driver=new ChromeDriver();
		//creating a driver of type web
		driver.get(baseurl); //opening base url in browser
		driver.findElement(By.linkText("Sign Up/Log In")).click();
		if(driver.findElement(By.name("user")).isDisplayed())
			System.out.println("The user textbox field is present");
		if(driver.findElement(By.name("pwd")).isDisplayed())
			System.out.println("The password textbox field is present");
		System.out.println(driver.findElement(By.name("user")).getText());
		System.out.println(driver.findElement(By.name("pwd")).getText());
		driver.findElement(By.name("user")).sendKeys("shubha");
		driver.findElement(By.name("pwd")).sendKeys("shubha@123");
		driver.findElement(By.name("rememberme")).click();
		driver.findElement(By.tagName("button")).submit();
		driver.quit();

	}








}
