package com.virtusa.testing.examples;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestButton_02 {
	public static void main(String[] args) {
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl="http://destinationqa.com/aut/RadioButtons.html"; //string url
		WebDriver driver=new ChromeDriver(); //creating a driver of type web
		driver.get(baseurl); //opening base url in browser
		/*
		 * WebElement radio= driver.findElement(By.name("groupName")); 
		 * radio.click();
		 */
		driver.findElement(By.xpath("//input[@value='Mon']"));
		System.out.println("radio actived");
		WebElement check1 = driver.findElement(By.name("orange"));
		check1.click();
		System.out.println("check1 actived");
		WebElement check2= driver.findElement(By.name("red"));
		check2.click();
		System.out.println("check2 actived");

		 driver.quit();

	}
}