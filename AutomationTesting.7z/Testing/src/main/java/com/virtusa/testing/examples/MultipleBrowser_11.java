package com.virtusa.testing.examples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MultipleBrowser_11 {
	public static void main(String[] args) {
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl=" http://accounts.google.com/ "; //string url
		WebDriver driver=new ChromeDriver();
		//creating a driver of type web
		driver.get(baseurl); //opening base url in browser

		WebElement terms = driver.findElement(By.linkText("Terms"));
		terms.click();

		WebElement privacy = driver.findElement(By.linkText("Privacy"));
		privacy.click();


		// Store the current window handle
		String winHandleBefore = driver.getWindowHandle();
		// Perform the click operation that opens new window

		// Switch to new window opened
		String[] links = null;
		int linksCount = 0;
		for(String winHandle : driver.getWindowHandles()){

			driver.switchTo().window(winHandle);
			List<WebElement> all_links_webpage = driver.findElements(By.tagName("a")); 
			System.out.println("Total no of links Available: " + all_links_webpage.size());
			int k = all_links_webpage.size();
			System.out.println("List of links Available: ");
			for(int i=0;i<k;i++)
			{
				if(all_links_webpage.get(i).getAttribute("href").contains("google"))
				{
					String link = all_links_webpage.get(i).getAttribute("href");
					System.out.println(link);
				}   
			}
		} 
		 driver.quit();
	}








}


