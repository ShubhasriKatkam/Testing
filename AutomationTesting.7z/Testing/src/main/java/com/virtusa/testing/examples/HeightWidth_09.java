package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HeightWidth_09 {

	public static void main(String[] args) {
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl=" http://newtours.demoaut.com/ "; //string url
		WebDriver driver=new ChromeDriver();
		//creating a driver of type web
		driver.get(baseurl); //opening base url in browser
		int h1=driver.findElement(By.name("userName")).getSize().getHeight();
		int w1=driver.findElement(By.name("userName")).getSize().getWidth();
		System.out.println("user name size ");
		int h2=driver.findElement(By.name("password")).getSize().getHeight();
		int w2= driver.findElement(By.name("password")).getSize().getWidth();
		System.out.println("password size ");
		if(h1==h2 && w1==w2)
		{
			System.out.println("heigth and width of text box are  same");
		}
		else
		{
			System.out.println("heigth and width of text box are not same");
		}
		driver.quit();

	}

}
