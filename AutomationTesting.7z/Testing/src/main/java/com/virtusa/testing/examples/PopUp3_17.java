package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PopUp3_17 {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("C:\\Users\\shubhasrik\\OneDrive - Virtusa\\Testing\\HTML Pages\\popup3.html");
		driver.findElement(By.tagName("button")).click();
		driver.switchTo().alert().sendKeys("Shubhasri");
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		System.out.println(driver.findElement(By.xpath("//p[@id='promptdemo']")).getText());
		driver.quit();
	}

}
