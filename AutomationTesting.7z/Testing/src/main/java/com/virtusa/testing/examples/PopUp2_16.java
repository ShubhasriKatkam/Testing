package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PopUp2_16 {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("C:\\Users\\shubhasrik\\OneDrive - Virtusa\\Testing\\HTML Pages\\popup2.html");
		driver.findElement(By.tagName("button")).click();
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		System.out.println(driver.findElement(By.xpath("//p[@id='confirmdemo']")).getText());
	 driver.quit();
	}

}
