package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Explicit_05 {

	public static void main(String[] args) {


		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		String baseurl="https://www.google.com";
		driver.get(baseurl);
		driver.findElement(By.xpath("//input[@value='']")).sendKeys("Automation Testing");
		System.out.println("searched a keyword");
		WebElement p = driver.findElement(By.name("btnK"));
		p.submit();
		System.out.println("Clicked on google search");
		WebDriverWait wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions.titleContains("Automation Testing"));
		if(driver.getTitle().contains("Automation testing"))
			System.out.println("Same");
	 driver.quit();
	}

}