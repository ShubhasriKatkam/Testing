package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TicketBookingVerify_08 {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		String baseurl="http://newtours.demoaut.com/";
		driver.get(baseurl);
		driver.findElement(By.name("userName")).sendKeys("mercury");
		System.out.println("user name entered ");
		driver.findElement(By.name("password")).sendKeys("mercury");
		System.out.println("password entered ");
		WebElement signin = driver.findElement(By.name("login"));
		signin.submit();
		System.out.println("login successfully  ");

		String fromPort= new Select(driver.findElement(By.name("fromPort"))).getFirstSelectedOption().getText();
		String toPort= new Select(driver.findElement(By.name("toPort"))).getFirstSelectedOption().getText();
		if(!fromPort.equals(toPort))
			System.out.println("Departing from is not same as Arriving ");
		else
			System.out.println("Departing from is same as Arriving ");
		driver.quit();
	}




}

