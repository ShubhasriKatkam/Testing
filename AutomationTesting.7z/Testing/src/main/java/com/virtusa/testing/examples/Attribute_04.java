package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Attribute_04 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		String baseurl="https://ebay.in";
		driver.get(baseurl);
		WebElement attribute1=driver.findElement(By.linkText("register"));
		String a1=attribute1.getAttribute("href");
		System.out.println("href is +"+a1);		
		String a2=attribute1.getAttribute("_sp");
		System.out.println("_sp is +"+a2);
		driver.quit();

	}

}
