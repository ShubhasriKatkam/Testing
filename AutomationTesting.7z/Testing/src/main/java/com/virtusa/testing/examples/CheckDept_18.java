package com.virtusa.testing.examples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckDept_18 {
	public static void main(String args[])
	{
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl="http://newtours.demoaut.com/"; //string url
		WebDriver driver=new ChromeDriver();	
		driver.get(baseurl); //opening base url in browser
		driver.findElement(By.name("userName")).sendKeys("mercury");
		System.out.println("user name entered ");
		driver.findElement(By.name("password")).sendKeys("mercury");
		System.out.println("password entered ");
		WebElement signin = driver.findElement(By.name("login"));
		signin.submit();
		System.out.println("login successfully  ");
		Select fromPort = new Select(driver.findElement(By.name("fromPort")));
		List<WebElement> options =fromPort.getOptions();
		if(options.contains("India"))
			System.out.println("India is Present");
		else
			System.out.println("India is Not present");
	    driver.quit();
		 }

}
