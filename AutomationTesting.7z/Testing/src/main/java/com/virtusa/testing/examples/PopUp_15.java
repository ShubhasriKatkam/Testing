package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PopUp_15 {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("C:\\Users\\shubhasrik\\OneDrive - Virtusa\\Testing\\HTML Pages\\popup.html");
		driver.findElement(By.tagName("button")).click();
		System.out.println("button clicked \n "+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		System.out.println("alert accept");
		driver.findElement(By.tagName("button")).click();
		System.out.println("button clicked");
		driver.switchTo().alert().dismiss();
		driver.quit();
	}

}
