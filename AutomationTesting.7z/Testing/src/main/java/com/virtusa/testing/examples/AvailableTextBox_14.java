package com.virtusa.testing.examples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AvailableTextBox_14 {
	public static void main(String[] args) {


		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		String baseurl=" http://accounts.google.com/";
		driver.get(baseurl);

		List<WebElement> boxes = driver.findElements(By.xpath("//input[@type='text']"));
		int numberOfBoxes = boxes.size();
		System.out.println(numberOfBoxes);

		for(WebElement box:boxes)
			System.out.println(box.getAttribute("value"));
		 driver.quit();

	}



}