package com.virtusa.testing.examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestEbay_01 {

	public static void main(String[] args) {
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl="https://ebay.in"; //string url
		WebDriver driver=new ChromeDriver();
		//creating a driver of type web
		driver.get(baseurl); //opening base url in browser
		driver.findElement(By.linkText("register")).click(); //clicking on register link
		driver.findElement(By.name("firstname")).sendKeys("shubha"); // finding element by name
		driver.findElement(By.id("lastname")).sendKeys("sri");   //finding element by id
		driver.findElement(By.name("email")).sendKeys("shubha@gmail.com");
		driver.findElement(By.name("PASSWORD")).sendKeys("shubha@123");
		driver.findElement(By.linkText("Create account")).click(); //clicking on create account button
	driver.quit();
	}

}
