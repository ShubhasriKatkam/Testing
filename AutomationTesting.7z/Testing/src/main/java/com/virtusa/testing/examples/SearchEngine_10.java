package com.virtusa.testing.examples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SearchEngine_10 {
	public static void main(String[] args) {
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		String baseurl=" http://www.google.com/ "; //string url
		WebDriver driver=new ChromeDriver();
		//creating a driver of type web
		driver.get(baseurl); //opening base url in browser
		driver.findElement(By.xpath("//input[@type='text']"));
		driver.findElement(By.name("q")).sendKeys("india");
		System.out.println("values sent");
		List<WebElement> listGoogle = driver.findElements(By.xpath("//ul[@role='listbox']"));

		driver.findElements(By.xpath("//li[@role='presentation']"));
		for (int i = 0; i < listGoogle.size(); i++) {
			System.out.println(listGoogle.get(i).getText());
			 driver.quit();
		}

	}
}
